import React from 'react'
import PagesHeader from '../layout/PagesHeader'

export default function HomePage() {
  return (
    <>
    <PagesHeader />
    <div>HomePage</div></>
  )
}
