import React from 'react'
import PagesHeader from '../layout/PagesHeader'

export default function ShopPage() {
  return (
   <><PagesHeader />
    <div>ShopPage</div></>
  )
}
