import React from 'react'
import PagesHeader from '../layout/PagesHeader'

function ProfilePage() {
  return (
    <><PagesHeader />
    <div>ProfilePage</div></>
  )
}

export default ProfilePage