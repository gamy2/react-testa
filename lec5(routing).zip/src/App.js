import './App.css';
import LoginPage from './view/pages/loginPage/Login';
import React from "react";
import {
  BrowserRouter as Router,
  Routes ,
  Route,
  Link
} from "react-router-dom";

import RegPage from './view/pages/RegPage';
import HomePage from './view/pages/HomePage';
import ProfilePage from './view/pages/ProfilePage';
import ShopPage from './view/pages/ShopPage';

function App() {
  return (
    <>
    <Router>
    <Routes >
    
      <Route path='/' element={<LoginPage/>} />
      <Route path='/reg' element={<RegPage/>} />
      <Route path='/home' element={<HomePage/>} />
      <Route path='/profile' element={<ProfilePage/>} />
      <Route path='/shop' element={<ShopPage/>} />
     
     
    </Routes >
    </Router>
    </>
  );
}

export default App;
