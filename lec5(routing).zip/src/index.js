import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import LoginPage from './view/pages/loginPage/Login';

import {
  BrowserRouter as Router,
  Routes ,
  Route,
  Link
} from "react-router-dom";

import RegPage from './view/pages/RegPage';
import HomePage from './view/pages/HomePage';
import ProfilePage from './view/pages/ProfilePage';
import ShopPage from './view/pages/ShopPage';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
<>
    <Router>
    <Routes >
    
      <Route path='/' element={<LoginPage/>} />
      <Route path='/reg' element={<RegPage/>} />
      <Route path='/home' element={<HomePage/>} />
      <Route path='/profile' element={<ProfilePage/>} />
      <Route path='/shop' element={<ShopPage/>} />
     
     
    </Routes >
    </Router>
    </>

);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
