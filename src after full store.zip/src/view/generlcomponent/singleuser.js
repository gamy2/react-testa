import React from 'react'

export default function SingleUser() {
  return (
    <div>SingleUser</div>
  )
}
