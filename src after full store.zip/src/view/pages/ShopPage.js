import React, { useEffect, useState } from 'react'
import { Link, useLoaderData, useLocation, useParams } from 'react-router-dom';
import DBconnection from '../../model/network';
import PagesHeader from '../layout/PagesHeader'

export default function ShopPage(param) {
 const[products, setProducts] =useState([]);
// mount
  useEffect(()=>{
DBconnection.get("products").then((res)=>{
  console.log(res.data);
  setProducts(res.data);
}).catch((err)=>{
  console.log(err);
  console.log("فى error")
})
},[])
  return (
   <><PagesHeader />
{products.map((product,index)=>{return<>
<Link to={"Product/"+product.id} ><h3 key={index}>{product.title}</h3></Link>
</>})}
   </>
  )
}
