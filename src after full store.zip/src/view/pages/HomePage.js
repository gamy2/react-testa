
import React from 'react'
import { useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import PagesHeader from '../layout/PagesHeader'

export default function HomePage() {
  const prp=useParams();
let lang=useSelector((state)=>{return state.user.data})
  const pages = ()=>{
    console.log(lang);
  }
  return (
    <>
    <PagesHeader />
    <div onClick={()=>pages()}>HomePage   {lang.age} </div></>
  )
}
