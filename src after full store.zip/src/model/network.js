import axios from 'axios';

const DBconnection=axios.create({
    //obj has an data about connection 
    baseURL:'https://fakestoreapi.com/'
    //user
    //password
    //method
})
DBconnection.interceptors.request.use((con)=>{
//  con.method = 'POST';
    console.log(con);
     return con;
},
function(error){});
DBconnection.interceptors.response.use((con)=>{
    console.log(con.data);
    
    return con;
},
function(error){});

 


export default DBconnection;