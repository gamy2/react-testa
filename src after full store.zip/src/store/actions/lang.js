export function changeLanng(yaser){
    return{
        type:"SET_LANG",
        payload:yaser,
    }

}