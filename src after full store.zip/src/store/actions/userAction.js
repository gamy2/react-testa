export function changeUser(data){
    return{
        type:"SET_USER",
        payload:data,
    }

}