const INIT={
    //  name:"ali",
    //    age:28
   data:{ name:"ali",
   age:28}
};

export default function UserReducer(state=INIT,action)
{
    if(action.type==="SET_USER")
    {
        // return{
        //     ...state,name:action.payload.name,age:action.payload.age};
        return{
              ...state,data:action.payload};
        }else{
            return{...state}
        }
    }
