import{combineReducers} from "redux"
import LangReducer from "./lang";
import UserReducer from './userReducer';

export default combineReducers({
lang:LangReducer,
user:UserReducer,

})