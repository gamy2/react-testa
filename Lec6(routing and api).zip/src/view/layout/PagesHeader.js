import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';

function PagesHeader() {
  return (<>
      <Navbar  bg="dark" variant="dark">
        <Container>
          <Navbar.Brand href="#home">Navbar</Navbar.Brand>
          <Nav className="me-auto">
            <Link to="/home" className='p-4'>Home</Link>
            <Link to="/profile"className='p-4'>profile</Link>
            <Link to="/shop"className='p-4'>shop</Link>
          </Nav>
        </Container>
      </Navbar>

   
      </>
  )
}
export default PagesHeader;
