import React from 'react'
import { useParams } from 'react-router-dom';
import PagesHeader from '../layout/PagesHeader'

export default function HomePage() {
  const prp=useParams();

  const pages = ()=>{
    console.log(prp);
  }
  return (
    <>
    <PagesHeader />
    <div onClick={()=>pages()}>HomePage</div></>
  )
}
