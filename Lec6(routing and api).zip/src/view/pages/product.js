import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import DBconnection from '../../model/network';
import PagesHeader from '../layout/PagesHeader';

export default function Product() {
    const pram=useParams();
    const id=pram.id;
    const[product, setProduct] =useState({});
    useEffect(()=>{
      DBconnection.get(`products/${id}`).then((res)=>{
        console.log(res.data);
        setProduct(res.data);
      }).catch((err)=>{
        console.log(err);
        console.log("فى error")
      })
      },[])
    
  return (
   <>
   <PagesHeader />
   <h3>{product.title}</h3>
   <h2>{product.price}$</h2>
   <img src={product.image}/>
   </>
  )
}
