import React from 'react'

export default function NotFound() {
  return (
    <div>Error 404</div>
  )
}
