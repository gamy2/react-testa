import './App.css';
import LoginPage from './view/pages/loginPage/Login';
import React from "react";
import {
  BrowserRouter ,
  Routes ,
  Route,
  useParams,
} from "react-router-dom";

import RegPage from './view/pages/RegPage';
import HomePage from './view/pages/HomePage';
import ProfilePage from './view/pages/ProfilePage';
import ShopPage from './view/pages/ShopPage';
import NotFound from './view/pages/404';
import Product from './view/pages/product';

function App() {
  let {id}=useParams();
  return (
    <>
    <BrowserRouter>
<Routes>
  <Route path="/" element={<LoginPage/>}/>
  <Route path="/home" element={<HomePage />} />
  <Route path="/profile" element={<ProfilePage />} />
  <Route path="/reg" element={<RegPage/>}/>
  <Route path="/shop" element={<ShopPage/>}/>
  <Route path="/shop/Product/:id" element={<Product/>}/>
  <Route path="*" element={<NotFound/>}/>
</Routes>
    </BrowserRouter>
    </>
  );
}

export default App;
