export function changeProducts(data){
    return{
        type:"SET_PRODUCTS",
        payload:data,
    }

}