export function changeLoader(data){
    return{
        type:"SET_LOADER",
        payload:data,
    }

}