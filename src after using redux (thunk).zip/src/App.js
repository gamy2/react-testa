import './App.css';
import LoginPage from './view/pages/loginPage/Login';
import React from "react";
import {
  BrowserRouter  as Routee,
  Routes ,
  Route,
  useParams,
} from "react-router-dom";

import RegPage from './view/pages/RegPage';
import HomePage from './view/pages/home';
import ProfilePage from './view/pages/ProfilePage';
import ShopPage from './view/pages/ShopPage';
import NotFound from './view/pages/404';
import Product from './view/pages/product';
import { useSelector } from 'react-redux';

function App() {
  
  let lang=useSelector((state)=>{return state.lang})
  return (
    <>
    <div dir={lang.lang=="en"?"ltr":"rtl"}>
    <Routee>
<Routes>
  <Route path="/" element={<LoginPage/>}/>
  <Route path="/home" element={<HomePage />} />
  <Route path="/profile" element={<ProfilePage />} />
  <Route path="/reg" element={<RegPage/>}/>
  <Route path="/shop" element={<ShopPage/>}/>
  <Route path="/shop/Product/:id" element={<Product/>}/>
  <Route path="*" element={<NotFound/>}/>
</Routes>
    </Routee>
    </div>
    </>
  );
}

export default App;
